const max = (a,b) => (a>b ? a :b)
const min = (a,b) => (a<b ? a :b)