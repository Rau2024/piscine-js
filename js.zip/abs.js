const abs = (n) => (n<0 ? -n :n);
const isPositive = (n) => n>0;