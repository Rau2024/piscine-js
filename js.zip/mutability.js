const clone1 = { ...person }; // shallow copy using spread
const clone2 = Object.assign({}, person); // shallow copy using Object.assign

const samePerson = person;

person.age += 1;
person.country = 'FR';