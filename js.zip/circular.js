const circular = {};
circular.circular = circular;