const escapeStr = "\` \\ \/ \'\""

const arr = Object.freeze([4, '2']);

// 3. Separate nested object and array, frozen
const nestedArr = Object.freeze([4, undefined, '2']);

const nestedObj = Object.freeze({
  str: "nested",
  num: 1,
  bool: true
});

const nested = Object.freeze({
  arr: nestedArr,
  obj: nestedObj
});

// 4. Main frozen object containing primitive and nested values
const obj = Object.freeze({
  str: "hello",
  num: 42,
  bool: false,
  undef: undefined,
  nested: nested
});