const get = (x) => sourceObject[x]
const set = (x,y) => {
    sourceObject[x]=y
    return y
}

