const smalls = -Infinity;
const biggie = Infinity;
