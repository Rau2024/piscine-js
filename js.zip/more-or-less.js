function more(x) {
  return x + 1;
}

function less(x) {
  return x - 1;
}

function add(a, b) {
  return a + b;
}

function sub(a, b) {
  return a - b;
}
