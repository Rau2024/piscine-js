const concatStr = (a, b) => String(a) + String(b);

