const first = (x) => x[0];

const last = (x) => x[x.length - 1];

const kiss = (x) => [last(x), first(x)];
