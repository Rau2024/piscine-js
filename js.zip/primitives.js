
const str = "z";
const num = 23;
const bool = true;
const undef = undefined;
