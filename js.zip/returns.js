const id = (x) => x;

const getLength = (x) => x.length;
